#!/usr/bin/python3
import fcntl
import struct
import os
import time
from scapy.all import *

TUNSETIFF = 0x400454ca
IFF_TUN = 0x0001
IFF_TAP = 0x0002
IFF_NO_PI = 0x1000

# Create the tun interface
tun = os.open("/dev/net/tun", os.O_RDWR)
ifr = struct.pack('16sH', b'tun%d', IFF_TUN | IFF_NO_PI)
ifname_bytes = fcntl.ioctl(tun, TUNSETIFF, ifr)

# Get the interface name
ifname = ifname_bytes.decode('UTF-8')[:16].strip("\x00")
print("Interface Name: {}".format(ifname))

os.system("ip addr add 192.168.53.1/24 dev {}".format(ifname))
os.system("ip link set dev {} up".format(ifname))

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("0.0.0.0", 5555))
ip="zero"
port=0
while True:
    # this will block until at least one interface is ready
    ready, _, _ = select([sock, tun], [], [])
    for fd in ready:
        if fd is sock:
              data, (ip, port) = sock.recvfrom(2048)
              pkt = IP(data)
              print("From inside packet <==: {} --> {}".format(pkt.src, pkt.dst))
              print("From outside socket: source ip {}, source port {}".format(ip, port))
              os.write(tun, bytes(pkt))
        if fd is tun:
            packet = os.read(tun, 2048)
            if port==0:
               print("this VPN needs to start from the client outside the private network\n")
               break
            else:
               sock.sendto(packet, (ip, port))
